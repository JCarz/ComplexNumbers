import java.util.*;

public class AnalysisTest {

	public static void main(String[] args) {
		int choice;
		double firstComplex1, firstComplex2;
		double secondComplex1, secondComplex2;
		Scanner input = new Scanner(System.in);
		/**
		 * Above are my variables including my scanner input no need to declare becasue
		 * they will be initiated throughout the program
		 */
		System.out.println("Please type your choice and enter : ");
		System.out.println("1.Add Two Complex Numbers");
		System.out.println("2.Substract Two Complex Numbers");
		choice = input.nextInt();
// This will prompt the user to pick either 1 or 2 to start the case depending on the choice variable 
		switch (choice) {
		case 1:
			System.out.println("Enter 2 complex numbers one after another: ");
			firstComplex1 = input.nextDouble();
			System.out.println("One more..");
			firstComplex2 = input.nextDouble();
// This code above will prompt the user to enter 2 numbers one after another to be stored into the c1 object

			System.out.println("Enter a Second you wish to subtract: ");
			secondComplex1 = input.nextDouble();
			System.out.println("One more..");
			secondComplex2 = input.nextDouble();
// This code above will prompt the user to enter 2 numbers one after another to be stored into the c2 object

			Analysis c1 = new Analysis(firstComplex1, firstComplex2);
			Analysis c2 = new Analysis(secondComplex1, secondComplex2);
// The above objects store the users input for each of the complex numbers 
			c1.add(c2);
//c1 object is added though the add method in the Analysis class with the c2 object in its parameters
			System.out.println(c1.toString());
			break;

		case 2:
			System.out.println("Enter 2 complex numbers one after another: ");
			firstComplex1 = input.nextDouble();
			System.out.println("One more..");
			firstComplex2 = input.nextDouble();
// This code above will prompt the user to enter 2 numbers one after another to be stored into the s1 object

			System.out.println("Enter a Second you wish to add: ");
			secondComplex1 = input.nextDouble();
			System.out.println("One more..");
			secondComplex2 = input.nextDouble();
// This code above will prompt the user to enter 2 numbers one after another to be stored into the s2 object

			Analysis s1 = new Analysis(firstComplex1, firstComplex2);
			Analysis s2 = new Analysis(secondComplex1, secondComplex2);
// The above objects store the users input for each of the complex numbers
			s1.sub(s2);
//s1 object is added though the subtracted method in the Analysis class with the s2 object in its parameters

			System.out.println(s1.toString());
			break;
		}

		input.close();
	}
}
