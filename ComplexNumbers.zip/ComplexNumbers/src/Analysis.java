import java.util.*;

public class Analysis {
	double realNum, imagNum;
	Scanner input = new Scanner(System.in);

	/**
	 * @param realNum this is the real part of the complex number
	 * @param imagNum this is the imaginary part of the complex number
	 */
	// constructor to initialize the complex number that helps an object of the
	// class when its declared
	Analysis(double realNumber, double imagNum) {
		this.realNum = realNumber;
		this.imagNum = imagNum;
	}

	/**
	 * this is a no argument constructor that has the default values that will be
	 * used if user has not initialized any values
	 */
	private Analysis() {
		this.realNum = 76.8;
		this.imagNum = 24.0;
	}

	public void add(Analysis num) {
		this.realNum = realNum + num.realNum;
		this.imagNum = imagNum + num.imagNum;
	}//This method will take the real number and add the parameters real number as well as the imaginary number 

	public void sub(Analysis num) {
		this.realNum = this.realNum - num.realNum;
		this.imagNum = this.imagNum - num.imagNum;
	}//This method will take the real number and add the parameters real number as well as the imaginary number 

	public String toString() {
		return"Total: "+ this.realNum + " + " + this.imagNum + "i";
	}

}
